# devfile-sample-java-springboot-basic
A basic sample application using Java Spring Boot with devfile
